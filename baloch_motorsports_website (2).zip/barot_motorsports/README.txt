BALOCH MOTORSPORTS — FREE WEBSITE

Files:
- index.html — the complete website (HTML/CSS/JavaScript in one file).

How to add another bike:
1. Open index.html in a text editor.
2. Find: const bikes = [
3. Copy one bike object (between { and }).
4. Paste it before the closing ]; and change name, year, mileage, image and specs.
5. Save the file.
6. Upload/replace index.html on your hosting.

Important:
- The 2016 H2 card uses a Wikimedia Commons H2 image from the same model family.
- The 2022 H2 card uses an H2 Carbon-family image as a representative image. For an exact 2022 H2 photograph, replace that image URL with your own licensed photo or an exact model-year image.
- Wikimedia images used here are CC BY-SA licensed; keep the attribution note on the page.

Free publishing:
Option A — GitHub Pages:
1. Create a free GitHub account.
2. Create a repository.
3. Upload index.html.
4. Settings → Pages → deploy from the main branch.
5. GitHub gives you a free *.github.io address.

The website needs no database, login, payment system or paid hosting.
